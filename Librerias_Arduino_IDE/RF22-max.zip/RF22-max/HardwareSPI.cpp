// HardwareSPI.h
// Author: Mike McCauley (mikem@open.com.au)
// Copyright (C) 2011 Mike McCauley
// Contributed by Joanna Rutkowska
// $Id: RF22.h,v 1.22 2012/09/05 23:31:39 mikem Exp mikem $

#include "HardwareSPI.h"

// Declare a single instance of the hardware SPI interface class
HardwareSPIClass Hardware_spi;
